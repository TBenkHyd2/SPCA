close all; clc; clear all; %mise a jour de toutes les variables 
% *****   PRINCIPAL COMPONENT ANALYSIS (SPCA 1.0)---  ANALYSE EN COMPOSANTES PRINCIPALES ****  ');
%      %%%%    By:  T. BENKACI & N.DECHEMI (2020)  %%%%     ');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% READ DATA FROM EXCEL FILE                                                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[DATA,TEXT]  = xlsread('DATA_1.xlsx'); % Exel File for DATA MATRIX AND VARIABLES LABELS
[L C] = size(DATA);
 
 % Observations File in Text Format
 b=1;
 if b==1 % use File in excel to read Observations Labels: Obs.xlsx
 [Num Obs]=xlsread('Obs1.xlsx');
elseif b==2 % Else write Labels of observations in Obs:
     Obs={'Serb' 'Clay' 'Bern' 'Yur' 'Zsiv' 'McM' 'Man' 'Her' 'Bar' 'Nool' 'Bourg',...
         'Serbl' 'Cla' 'Karp' 'Mcey' 'Warnr' 'Zszk' 'Herm' 'Bard' 'Schw' 'Pogr' 'Schn' 'Bars'};
 end
 
 %CLUSTERING METHOD
 KC=1; % KC=1 ---- K-nearest neighbors (KNN) by Default
% if KC=1 :  K-nearest neighbors (KNN) Clustering  (Supervised classification algorithm) by Default
% if KC=2 :  K-means Clustering using a pre-specified  number of clusters  (Unsupervised Clustering) 
% if KC=3 :  Hierarchical Clustering Tree (Optionnal)  
if L<=4; %Number of clusters - L: Number of Varibales
    nc=0; disp ('No Clustering')
elseif  L >5 & L <=9      
nc=3;
elseif  L >10 & L<=15
nc=4;
    elseif L>15 & L<=50
nc=5;% Number of clusters on K-mean and Hierarchical Clustering Method: L Number of Varibales
elseif L>50
    nc=round(sqrt(L))-1;
    end
% nc = % You can Modify the number of Clusters here

 % DISPLAYS: CORRELATION MATRIX, EIGENVECTORS & EIGENVALUES ... 
 % & OTHERS RESULTS: 
 [V,P,coeff,score,F,CP,VCP, DD,CV,CT,CIN] = PCA_ENG(DATA,TEXT,L,C,Obs,KC,nc);
 


