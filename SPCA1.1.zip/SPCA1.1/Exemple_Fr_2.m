close all; clc; clear all; %Fermeture des graphes mise a jour de toutes les variables 
% *****   ANALYSE EN COMPOSANTES PRINCIPALES (SPCA 1.0)---PRINCIPAL COMPONENT ANALYSIS   ****  ');
%      %%%%    By:  T. BENKACI & N.DECHEMI (2020)  %%%%     ');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LECTURE DES DONNEES A PARTIR D'UN FICHIER EXCEL                                                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[DATA,TEXT]  = xlsread('DATA_2.xlsx'); % Nom du fichier �tudi�
[L C] = size(DATA);
 % DONNEES DES Observations  FICHIER EN EXCEL
 b=1;
 if b==1 % utiliser un fichier sur excel: Obs.xlsx ou ex txt
 [Num Obs]=xlsread('Obs2.xlsx');
 elseif b==2 % Else write Labels of observations in Obs:
  Obs={'Alab' 'Alask' 'Arizo' 'Arkans' 'Califr' 'Color' 'Concut' 'Delaw' 'DColum' 'Flori' 'Georg' 'Hawa' 'Idaho',...
 'Ilnois' 'India' 'Iowa' 'Kanss' 'Kecky' 'Louisi' 'Maine' 'Maryld' 'Massac' 'Michig' 'Minne' 'Missip' 'Missri' 'Mont' 'Nebra' 'Neva' 'NHamp',...
 'NJers' 'NMex' 'NYokr' 'NCar' 'NDak' 'Ohio' 'Okla' 'Ore' 'Pensyl' 'RIsl' 'SCar' 'SDak' 'Tens' 'Texs' 'Utah' 'Verm' 'Virgi',...
 'Wash' 'WVirg' 'Wisc' 'Wyom'};
 end
 
 % CLASSIFICATION DES OBSERVATIONS PAR TROIS METHODES: KNN- K-MEANS- CAH
 KC=2; % KC=1 ---- K-nearest neighbors (KNN) by Default
% if KC=1 :  K-nearest neighbors (KNN) Clustering  (Supervised classification algorithm) by Default
% if KC=2 :  K-means Clustering using a pre-specified  number of clusters  (Unsupervised Clustering) 
% if KC=3 :  Hierarchical Clustering Tree (Optionnal)  
if L<=4; %Number of clusters - L: Number of Varibales
    nc=0; disp ('No Clustering')
elseif  L >5 & L <=9      
nc=3;
elseif  L >10 & L<=15
nc=4;
    elseif L>15 & L<=50
nc=5;% Number of clusters on K-mean and Hierarchical Clustering Method: L Number of Varibales
elseif L>50
    nc=round(sqrt(L))-1;
    end
% nc = % Changer le nombre de Clusters -- You can fix the number of Clusters here

 % AFFICHAGE DES CALCULS : MATRICE DE CORRELATION, VECTEURS VALEURS ET PROPRES 
 % & DES RESULTATS: 
 [V,P,coeff,score,F,CP,VCP, DD,CV,CT,CIN] = ACP_FR(DATA,TEXT,L,C,Obs,KC,nc);
 
